indigo-yamaharx
===============

[Indigo](http://www.perceptiveautomation.com/indigo/index.html) plugin -  Control of Yamaha RX-A1010, Main Zone plus toggle Party Mode

### Requirements

1. [Indigo 6](http://www.perceptiveautomation.com/indigo/index.html) or later (pro version only)
2. Yamaha RX Series A/V Receiver (needs to be accessible via network from the box hosting your Indigo server)

### Installation Instructions

1. Download latest release [here](https://github.com/discgolfer1138/indigo-yamaharx/releases)
2. Follow [standard plugin installation process](http://bit.ly/1e1Vc7b)

### Compatible Hardware
This plugin has only been tested with the Yamaha RX-A1010 (Australian Version)

